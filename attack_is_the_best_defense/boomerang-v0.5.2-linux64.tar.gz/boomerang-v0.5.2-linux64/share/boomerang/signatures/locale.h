char *setlocale(int category, const char *locale);
