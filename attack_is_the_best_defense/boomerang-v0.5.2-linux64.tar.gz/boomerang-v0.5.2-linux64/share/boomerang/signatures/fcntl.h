int open(const char *path, int flags, ...);
int creat(const char *pathname, unsigned int mode);
