
typedef long ptrdiff_t;

typedef unsigned int size_t;
// max_align_t
typedef void *nullptr_t;
