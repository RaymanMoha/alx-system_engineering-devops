
typedef struct _lconv lconv;
