
typedef int main(int argc, char *argv[]);
void __stack_chk_fail(void);
