
int   advance(const char *string, const char *expbuf);
char *compile(char *instring, char *expbuf, const char *endbuf, int eof);
int   step(const char *string, const char *expbuf);
