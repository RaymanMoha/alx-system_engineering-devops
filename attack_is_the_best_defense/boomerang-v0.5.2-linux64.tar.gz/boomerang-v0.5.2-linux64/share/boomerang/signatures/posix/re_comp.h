
char  *re_comp(const char *string);
int    re_exec(const char *string);
