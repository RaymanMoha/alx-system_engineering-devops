
int  creat(const char *path, mode_t mode);
int  fcntl(int fildes, int cmd, ...);
int  open(const char *path, int oflag, ...);
