
ssize_t strfmon(char *s, size_t maxsize, const char *format, ...);
