
typedef int nl_item;

char *nl_langinfo(nl_item item);
