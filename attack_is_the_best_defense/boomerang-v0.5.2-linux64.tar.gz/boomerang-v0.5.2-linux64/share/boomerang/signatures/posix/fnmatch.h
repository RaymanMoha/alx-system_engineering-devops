
int fnmatch(const char *pattern, const char *string, int flags);
