
long ulimit(int cmd, ...);
