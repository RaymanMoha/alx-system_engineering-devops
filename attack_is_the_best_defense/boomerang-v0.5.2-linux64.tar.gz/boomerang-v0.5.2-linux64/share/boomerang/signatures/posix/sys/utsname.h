
int uname(struct utsname *name);
