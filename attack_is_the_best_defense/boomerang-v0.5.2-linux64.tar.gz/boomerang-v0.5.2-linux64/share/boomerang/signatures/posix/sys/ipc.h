
typedef struct _key_t key_t;

key_t ftok(const char *path, int id);
