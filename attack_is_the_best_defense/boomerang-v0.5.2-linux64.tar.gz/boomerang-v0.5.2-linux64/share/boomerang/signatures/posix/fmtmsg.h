

int fmtmsg(long classification, const char *label, int severity,
           const char *text, const char *action, const char *tag);
