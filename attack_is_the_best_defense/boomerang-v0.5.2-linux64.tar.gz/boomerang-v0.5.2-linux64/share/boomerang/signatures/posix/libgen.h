
char  *basename(char *path);
char  *dirname(char *path);
char  *regcmp(const char *string1, ...);
char  *regex(const char *re, const char *subject, ...);
