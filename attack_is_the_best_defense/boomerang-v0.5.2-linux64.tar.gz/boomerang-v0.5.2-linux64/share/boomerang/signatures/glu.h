char *gluErrorString(GLenum errorCode);
