void f_setarg(int argc, char *argv[]);
void f_setsig();
void f_init();
void f_exit();

void do_lio(void *arg0, void *arg1, void *arg2, int arg3);
